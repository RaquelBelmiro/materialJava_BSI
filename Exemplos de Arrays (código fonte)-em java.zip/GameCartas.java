import java.util.Scanner;

public class GameCartas {
	private static Scanner in;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String[] naipes = {"Ouro", "Copas", "Espada", "Paus"};
		String[] baralho = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Valente", "Dama", "Rei"};
		in = new Scanner(System.in);
		
		System.out.print("Quantas cartas deseja mostrar? ");
		int qtde_cartas = in.nextInt();
		
		for(int i=0; i < qtde_cartas; i++)
		{ 	// Sorteia um naipe e uma carta do baralho
			String naipe = naipes[(int) (Math.random() * 4)];
			String carta = baralho[(int) (Math.random()*baralho.length)];
			
			System.out.println("\n Carta Sorteada = "+naipe+ " - " + carta );	
		}
		
		System.out.print("\n *** FIM DO GAME ***");
	}
}
