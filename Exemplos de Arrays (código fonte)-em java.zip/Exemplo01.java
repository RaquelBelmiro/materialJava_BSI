import java.util.Scanner;
// Detalhes sobre a API Scanner - Consulte o link abaixo
// https://www.devmedia.com.br/como-funciona-a-classe-scanner-do-java/28448
//forma simples de fazer entrada de dados via Console
	
public class Exemplo01 {
	private static Scanner in;

	public static void main(String[] args)
	{
		int num[] = new int[5];
		in = new Scanner(System.in);
		
		for(int i=0; i < num.length; i++)
		{	System.out.print("Informe um numero:");
			num[i] = in.nextInt();
		}
		
		System.out.print("Numeros:");
		for(int i= num.length-1; i >=0; i--) 
		{	System.out.print(num[i] + " - ");	}
		
		System.out.print("Numeros:");
		//comando FOR aprimorado - for(parametro : objeto)
		
		for(int i : num ) 
		{	System.out.print(i + " - ");	}
	}
}
