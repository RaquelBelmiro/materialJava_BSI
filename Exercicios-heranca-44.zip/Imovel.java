public class Imovel{
  protected String end;
  protected float preco;
  public Imovel(String end, float preco){
  }

  public void setpreco(){
    this.preco = 95000;
  }
  public float getpreco(){
    return this.preco;
  }
  public void setend(){
  this.end = "Rua Presente de Natal";
  }
  public String getend(){
    return this.end;
  }
}