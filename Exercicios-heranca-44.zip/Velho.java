public class Velho extends Imovel{
  public Velho(String end, float preco){
    super(end, preco);
  }
  public void setpreco(int preco){
    this.preco = preco;
  }
  public void getValor(){
    System.out.println("Valor do Imovel Velho"+ super.getpreco() - this.preco);
  }
}