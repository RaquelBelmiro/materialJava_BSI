public class Novo extends Imovel{
  public Novo(String end, float preco){
    super(end, preco);
  }
  public void setpreco(int preco){
    this.preco = preco;
  }
  public void getValor(){
    System.out.println("Valor do Imovel Novo"+ super.getpreco() + this.preco);
  }
}