public class VIP extends Ingresso{
  public VIP (float valor){
    super(valor);
  }
  public double retornaValor(){
    return super.getValor() * 2.1;
  }
}