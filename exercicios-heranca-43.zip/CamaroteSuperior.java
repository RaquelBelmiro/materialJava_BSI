public class CamaroteSuperior extends VIP{
  public CamaroteSuperior(float valor){
    super(valor);
  }
  public double CamaroteSup(){
    return super.getValor() * 3.7;
  }
}