abstract class Ingresso{
  protected float valor;
  public Ingresso(float valor){
    this.valor = valor;
  }

  public void setvalor (){
    this.valor = 10;
  }
  public float getValor(){
    return this.valor;
  }
  public void imprimeValor(){
    System.out.println(getValor());
  }
}