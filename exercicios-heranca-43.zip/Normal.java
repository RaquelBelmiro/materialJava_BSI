public class Normal extends Ingresso{
  public Normal(float valor){
    super(valor);
  }
  public void ImprimeIngresso(){
    System.out.println("Ingresso Normal: "+super.getValor());
  }
}