public class CamaroteInferior extends VIP{
  public CamaroteInferior(float valor){
    super(valor);
  }
  private String Localizacao;
  public void setLocalizacao(){
    this.Localizacao = "Camarote Inferior";
  }
  public String getLocalizacao(){
    return this.Localizacao;
  }
  public void localizaIngresso(){
    System.out.println(getLocalizacao());
  }
}