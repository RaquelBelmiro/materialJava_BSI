import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Exemplo06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 
		List<String> lista = new ArrayList<>();
		lista.add("S�rgio");
		lista.add("Paulo");
		lista.add("Guilherme");
		lista.add("Maria");

		System.out.println("Lista Atual: "+lista);
		
		lista.add(0,"Maria"); //permite elementos duplicados
		lista.add(2,"Carlos");
		
		System.out.println("\nLista Sem Ordena��o: "+lista);
		
		Collections.sort(lista);
		
		System.out.println("\nLista Ordenada: " +lista);
		
	}

}
