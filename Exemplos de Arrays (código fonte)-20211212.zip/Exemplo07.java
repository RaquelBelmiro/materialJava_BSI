import java.util.ArrayList;
import java.util.Iterator;

public class Exemplo07 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// criando um arraylist que s� ir� aceitar String
		ArrayList<String> c = new ArrayList<String>();
		  
		c.add("Rodrigo"); //adicionando ao final da lista, posi��o 0
		c.add("Maria");   //adicionando ao final da lista, posi��o 1
		c.add("Thiago");  //adicionando ao final da lista, posi��o 2
		c.add("Jo�o");    //adicionando ao final da lista, posi��o 3
		  
		//pegando o a quantidade de objetos - sa�da: Tamanho: 4
		System.out.println("Tamanho: " + c.size() );
		      
		//pegando um objeto especifico - sa�da: A string na posi��o 2: Thiago
		System.out.println("A string na posi��o 2: " + c.get(2) );
		                  
		//pegando a posi��o de um determinado objeto - sa�da: A posi��o da String 'Maria': 1
		System.out.println("A posi��o da String 'Maria': " + c.indexOf("Maria") );
		          
		//removendo a String na posi��o 1, ou seja "Maria"
		c.remove( 1 ); 
		                  
		System.out.println("============================");        
		System.out.println("** Lista percorrida com Iterator **");
		
		//percorrendo atrav�s de  um iterator(objeto respons�vel por percorrer uma cole��o)
		Iterator<String> i = c.iterator();// pegando o iterator da cole��o
		while( i.hasNext() ){//enquanto tiver um pr�ximo objeto na cole��o
		    //retorna o pr�ximo elemento da cole��o e incrementa o contador interno do iterator
		    String nome = i.next();
		  
		    System.out.println( nome );
		}
		                  
		System.out.println("============================");
		System.out.println("** Lista com mais nomes e percorrida com FOR aprimorado **");
		                  
		// adicionando na posi��o 1 a String "Mario", sendo que a o objeto que est� na
		// posi��o 1 passa para a posi��o 2, o objeto na posi��o 2 para 3 e assim por diante
		c.add(1, "Mario");  
		                  
		//percorrendo a lista atrav�s de um "for aprimorado" 
		//para cada objeto presente na lista "c" o objeto ser� coloca em "nome" e executar� o bloco
		for(String nome : c){
		    System.out.println( nome );
		}
		          
		System.out.println("============================");
		System.out.println("** Rela��o de nomes do Array **");
				  
		//criando um array com o mesmo tamanho dos objetos da cole��o
		String[] nomes = new String[ c.size() ];
		          
		//colocando os objetos da cole��o dentro do array passado por par�metro
		c.toArray( nomes );
		          
		//percorrendo o array
		for(int j = 0 ; j < nomes.length ; j++){
		    System.out.println(nomes[j]);
		}
			
	}
}
